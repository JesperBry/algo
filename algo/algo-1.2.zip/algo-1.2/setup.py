# -*- coding: utf-8 -*-

from setuptools import setup

setup(
    name='algo',    # This is the name of your PyPI-package.
    version='1.2',                          # Update the version number for new releases
    scripts=['algo']                  # The name of your scipt, and also the command you'll be using for calling it
)
